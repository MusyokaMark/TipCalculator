package com.example.tipcalculator;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    private SeekBar seekBar;
    private TextView txt1,txt2,txt3;
    private EditText edit;
    private int storepercentage;
    private float enteredBill;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit = findViewById(R.id.editBillAmt);
        txt1 = findViewById(R.id.txtTippercent);
        txt2 = findViewById(R.id.txtAmtTip);
        txt3 = findViewById(R.id.txtTotalAmt);
        seekBar = findViewById(R.id.seekBar);
        seekBar.setProgress(0);


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                NumberFormat f = NumberFormat.getCurrencyInstance();
                if (edit.getText() == null || edit.getText().equals("")) {
                    seekBar.setProgress(0);
                    txt2.setText(f.format(0));
                    txt3.setText(f.format(0));
                    return;
                }
                txt1.setText(String.valueOf(seekBar.getProgress())+"%");
                storepercentage = seekBar.getProgress();
                try {
                    enteredBill = Float.parseFloat(edit.getText().toString());
                    double tip = (enteredBill * storepercentage) /100;
                    double total = (tip+enteredBill);
                    txt2.setText(f.format(tip));
                    txt3.setText(f.format(total));

                }catch (Exception e){
                    edit.requestFocus();
                    edit.setText("");
                    seekBar.setProgress(0);
                    txt2.setText(f.format(0));
                    txt3.setText(f.format(0));
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    }
}
